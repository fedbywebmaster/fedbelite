<?php
require_once '../../../../wp-load.php';
$beeteam368_youtube_automatic_cron_job = 	new beeteam368_youtube_automatic_action();
$beeteam368_youtube_automatic_cron_job -> 	beeteam368_youtube_automatic_cron_job();