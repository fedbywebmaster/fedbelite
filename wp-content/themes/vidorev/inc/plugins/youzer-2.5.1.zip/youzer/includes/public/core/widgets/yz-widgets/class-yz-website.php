<?php

class YZ_Website_Info_Box extends YZ_Info_Box {

}